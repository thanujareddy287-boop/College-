const API_URL = "http://localhost:8080/student-management-api/api/students";

const form = document.getElementById("studentForm");
const tableBody = document.getElementById("studentTableBody");
const searchInput = document.getElementById("searchInput");
const countText = document.getElementById("countText");
const message = document.getElementById("message");

let students = [];

document.addEventListener("DOMContentLoaded", loadStudents);
form.addEventListener("submit", saveStudent);
searchInput.addEventListener("input", renderStudents);
document.getElementById("cancelButton").addEventListener("click", resetForm);

async function loadStudents() {
    try {
        const response = await fetch(API_URL);
        if (!response.ok) throw new Error("Could not load students.");
        students = await response.json();
        renderStudents();
    } catch (error) {
        showMessage(error.message + " Check that MySQL and Tomcat are running.", true);
        tableBody.innerHTML = `<tr><td colspan="7" class="empty">Unable to connect to Java API.</td></tr>`;
    }
}

function renderStudents() {
    const term = searchInput.value.trim().toLowerCase();

    const filtered = students.filter(s =>
        s.name.toLowerCase().includes(term) ||
        s.email.toLowerCase().includes(term) ||
        s.course.toLowerCase().includes(term)
    );

    countText.textContent = `${filtered.length} student(s)`;

    if (!filtered.length) {
        tableBody.innerHTML = `<tr><td colspan="7" class="empty">No students found.</td></tr>`;
        return;
    }

    tableBody.innerHTML = filtered.map(s => `
        <tr>
            <td>${escapeHtml(s.id)}</td>
            <td>${escapeHtml(s.name)}</td>
            <td>${escapeHtml(s.email)}</td>
            <td>${escapeHtml(s.course)}</td>
            <td>${escapeHtml(s.age)}</td>
            <td>${escapeHtml(s.phone || "-")}</td>
            <td>
                <button class="edit" onclick="editStudent(${s.id})">Edit</button>
                <button class="danger" onclick="deleteStudent(${s.id})">Delete</button>
            </td>
        </tr>
    `).join("");
}

async function saveStudent(event) {
    event.preventDefault();

    const id = document.getElementById("studentId").value;

    const student = {
        name: document.getElementById("name").value.trim(),
        email: document.getElementById("email").value.trim(),
        course: document.getElementById("course").value.trim(),
        age: Number(document.getElementById("age").value),
        phone: document.getElementById("phone").value.trim()
    };

    try {
        const response = await fetch(id ? `${API_URL}/${id}` : API_URL, {
            method: id ? "PUT" : "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(student)
        });

        const data = await response.json();

        if (!response.ok) {
            throw new Error(data.error || "Operation failed.");
        }

        showMessage(id ? "Student updated successfully." : "Student added successfully.");
        resetForm();
        await loadStudents();
    } catch (error) {
        showMessage(error.message, true);
    }
}

function editStudent(id) {
    const student = students.find(s => s.id === id);
    if (!student) return;

    document.getElementById("studentId").value = student.id;
    document.getElementById("name").value = student.name;
    document.getElementById("email").value = student.email;
    document.getElementById("course").value = student.course;
    document.getElementById("age").value = student.age;
    document.getElementById("phone").value = student.phone || "";

    document.getElementById("formTitle").textContent = "Edit Student";
    document.getElementById("saveButton").textContent = "Update Student";
    document.getElementById("cancelButton").hidden = false;

    window.scrollTo({ top: 0, behavior: "smooth" });
}

async function deleteStudent(id) {
    const student = students.find(s => s.id === id);
    if (!student) return;

    if (!confirm(`Delete ${student.name}?`)) return;

    try {
        const response = await fetch(`${API_URL}/${id}`, { method: "DELETE" });
        const data = await response.json();

        if (!response.ok) throw new Error(data.error || "Delete failed.");

        showMessage("Student deleted successfully.");
        await loadStudents();
    } catch (error) {
        showMessage(error.message, true);
    }
}

function resetForm() {
    form.reset();
    document.getElementById("studentId").value = "";
    document.getElementById("formTitle").textContent = "Add Student";
    document.getElementById("saveButton").textContent = "Add Student";
    document.getElementById("cancelButton").hidden = true;
}

function showMessage(text, isError = false) {
    message.hidden = false;
    message.textContent = text;
    message.style.background = isError ? "#fde8e8" : "#eef6ff";
    message.style.color = isError ? "#b42318" : "#1d4ed8";

    setTimeout(() => {
        message.hidden = true;
    }, 4000);
}

function escapeHtml(value) {
    return String(value ?? "")
        .replaceAll("&", "&amp;")
        .replaceAll("<", "&lt;")
        .replaceAll(">", "&gt;")
        .replaceAll('"', "&quot;")
        .replaceAll("'", "&#039;");
}
